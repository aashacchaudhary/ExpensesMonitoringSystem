# Repository file structure

Generated: 2026-07-24T21:42:05+05:45

A cleaner, hierarchical view of the repository. Directories end with '/'.
Cache folders (.ruff_cache, .pytest_cache, __pycache__) are summarised.
Excluded: .agents, .git, FILE_STRUCTURE.md.

## Summary
- Directories: 12
- Files: 41

## Tree
├── expense_manager/
│   ├── __pycache__/ (summary: compiled/pycache)
│   ├── __init__.py (2.0 B)
│   ├── asgi.py (233.0 B)
│   ├── settings.py (2.3 KB)
│   ├── urls.py (207.0 B)
│   └── wsgi.py (233.0 B)
├── expenses/
│   ├── __pycache__/ (summary: compiled/pycache)
│   ├── migrations/
│   │   ├── __pycache__/ (summary: compiled/pycache)
│   │   ├── 0001_initial.py (4.3 KB)
│   │   ├── 0002_familybudget.py (1.7 KB)
│   │   ├── 0003_usersecurityanswer.py (2.2 KB)
│   │   └── __init__.py (0.0 B)
│   ├── static/
│   │   └── expenses/
│   │       ├── css/
│   │       │   └── styles.css (19.8 KB)
│   │       └── js/
│   │           └── charts.js (6.4 KB)
│   ├── templates/
│   │   └── expenses/
│   │       ├── base.html (6.2 KB)
│   │       ├── budget_form.html (3.2 KB)
│   │       ├── dashboard.html (10.8 KB)
│   │       ├── expense_form.html (2.3 KB)
│   │       ├── expense_list.html (6.9 KB)
│   │       ├── family_group.html (4.9 KB)
│   │       ├── family_report.html (20.2 KB)
│   │       ├── home.html (3.5 KB)
│   │       ├── login.html (2.1 KB)
│   │       ├── monthly_report.html (9.7 KB)
│   │       ├── password_reset_confirm.html (1.8 KB)
│   │       ├── password_reset_email.html (1.5 KB)
│   │       ├── password_reset_security.html (1.5 KB)
│   │       ├── profile.html (4.4 KB)
│   │       └── register.html (2.0 KB)
│   ├── __init__.py (2.0 B)
│   ├── admin.py (1.8 KB)
│   ├── apps.py (154.0 B)
│   ├── forms.py (10.1 KB)
│   ├── models.py (6.0 KB)
│   ├── pdf_builder.py (13.0 KB)
│   ├── tests.py (18.1 KB)
│   ├── urls.py (1.2 KB)
│   └── views.py (36.8 KB)
├── db.sqlite3 (200.0 KB)
├── manage.py (681.0 B)
├── prepare_config.json (675.0 B)
├── prepare_for_deepseek.py (17.9 KB)
├── README.md (2.8 KB)
└── requirements.txt (18.0 B)
